A Pen created at CodePen.io. You can find this one at https://codepen.io/emeeks/pen/EoqRLa.

 A joy plot based on the language associated with probability.